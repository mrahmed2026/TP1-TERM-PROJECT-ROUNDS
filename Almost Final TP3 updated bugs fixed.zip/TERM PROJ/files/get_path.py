import os
def getPath():
    current_dir = os.getcwd() 
    path = os.path.abspath(os.path.join(current_dir, os.pardir))
    return path +"/"