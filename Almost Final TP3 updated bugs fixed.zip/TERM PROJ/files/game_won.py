from pygame.locals import *
from get_path import getPath
path = getPath()

def gamewon(difficulty, level):
    from main_game import maingame
    import pygame, sys
    import button
    from start_menu import start
    # Initialize Pygame
    mainClock = pygame.time.Clock()
    pygame.init()
    pygame.display.set_caption('game base')
    monitorSize = [pygame.display.Info().current_w, pygame.display.Info().current_h]
    screen = pygame.display.set_mode(monitorSize, pygame.FULLSCREEN)

    
    if level == 1:
        difficulty = "medium"
        maingame(difficulty)
    elif level == 2:
        difficulty = "hard"
        maingame(difficulty)
    else:
        screen.fill((255,255,255))
        # Define the font and font size for the credits text
        creditFont = pygame.font.Font(None, 80)
        # Render the "created by" text and blit it to the center of the screen
        text = creditFont.render("YOU WIN", True, (0, 0, 0))
        rect = text.get_rect(center=(monitorSize[0]//2, monitorSize[1]//2 - 50))
        screen.blit(text, rect)
        text2 = creditFont.render("WELL DONE", True, (0, 0, 0))
        rect2 = text2.get_rect(center=(monitorSize[0]//2, monitorSize[1]//2 + 20))
        screen.blit(text2, rect2)
        exitImage = pygame.image.load(f"{path}buttons/exit_button.png")
        main_menu_Image = pygame.image.load(f"{path}buttons/main_menu_button.png")
        exitButton = button.Button(monitorSize[0]//2 - 120,(monitorSize[1]//2)+200,exitImage,0.4)
        main_menu_Button = button.Button(monitorSize[0]//2 + 150,(monitorSize[1]//2)+200,main_menu_Image,0.4)
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        pygame.quit()
                        sys.exit()
            if exitButton.draw(screen):
                pygame.quit()
                sys.exit()
            if main_menu_Button.draw(screen):
                pygame.time.wait(500) # add a small delay
                start()
            pygame.display.update()




