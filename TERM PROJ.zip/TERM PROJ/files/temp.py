# def indexMap(L):
#     if len(L) == 0:
#         return {}
#     else:
#         value = indexMap(L[1:])
#         if L[0] not in value:
#             value[L[0]] = [L.index(L[0])]
#         elif L[0] in value:
#             value[L[0]] += [L.index(L[0])]
#     return value
# print(indexMap([5,6,5]))

# def ct2(n, d):
#     print(f"IN n: {n} d: {d}")
#     if (n <= 2):
#         return 2+abs(n)
#     else:
#         ans = n + ct2(n-2, d+1)
#         print(f"MID: {ans}")
#         ans += ct2(n//2, d+1)
#         print(f"OUT {ans} d: {d}")
#         return ans

# print(ct2(5, 0))

# def ishandy(word,hand):
#     word = word.lower()
#     hand = hand.lower()
#     wordD = {}
#     handD = {}
#     for i in word:
#         if i in wordD:
#             wordD[i] += 1
#         else:
#             wordD[i] = 1
#     for x in hand:
#         if x in handD:
#             handD[x] += 1
#         else:
#             handD[x] = 1
#     for k in word:
#         if wordD[k] <=  handD[k]:
#             None
#         else: 
#             return False
#     return True


# print(ishandy("lecture", "eetucrlabydf"))



# def rocHelper(t,d):
#     if len(t) <= 1:
#         return False
#     if len(t) == 2:
#         return d == 0 and t == "ab"
#     h = len(t)//2
#     if len(t)%2 == 0:
#         return rocHelper(t[:h],d-1) and rocHelper(t[h:],d-1)
#     else:
#         return rocHelper(t[:h],d-1) and rocHelper(t[h+1:],d-1) and int(t[h])==d
    
# def roc2(t):
#     return rocHelper(t,2)

# print(roc2("abababab"))




# def recSumConsecutivePairs(L):
#     if len(L) < 2:
#         return []
#     else:
#         value = [L[0]+L[1]]
#         return value + recSumConsecutivePairs(L[1:])






# assert(recSumConsecutivePairs([3,2,5,1]) == [5,7,6]) # 3+2, 2+5, 5+1
# assert(recSumConsecutivePairs([-1,4,10,2,0]) == [3,14,12,2]) # -1+4, 4+10, 10+2, 2+0
# assert(recSumConsecutivePairs([1]) == []) # no consecutive pairs
# assert(recSumConsecutivePairs([]) == []) # no consecutive pairs
# print("Pass")


# class Cart(object):
#     def __init__(self,s):
#         self.s = s
#         self.status = "open"
#     def getItems(self):
#         newS = self.s.split(",")
#         for i in range(len(newS)):
#             newS[i] = newS[i].lower()  
#         newSet = set(newS)
#         return newSet
    
#     def itemCount(self):
#         return len(Cart.getItems(self))
    
#     def addItem(self,item):
#         item = item.lower()
#         if item in Cart.getItems(self) or self.status == "closed":
#             return False
#         else:
#             self.s += (","+item)    
#             return True
#     def checkout(self):
#         self.status = "closed"
#     def __repr__(self):
#         return f"Shopping Cart: {Cart.itemCount(self)} item(s)"
# class WishList (Cart):
#     def checkout(self):
#         self.status = "open"
#     def __repr__(self):
#         return f"Wish List: {Cart.itemCount(self)} item(s)"



# m1 = Cart('milk,eggs,MILK')
# assert(m1.itemCount() == 2) # milk and eggs
# # The .getItems method should return a set of unique items present in the cart
# assert(m1.getItems() == {'milk', 'eggs'})
# # Note that these items are lowercase. Ignore case and duplicates
# m2 = Cart('Tomatoes,ONION,water,chips,CHIPS')
# assert(m2.getItems() == {'tomatoes','onion','water','chips'})
# assert(m2.itemCount() == 4) # Still just four items
# assert(str(m2) == "Shopping Cart: 4 item(s)")
# m3 = Cart('MILK')
# assert(str(m3) == "Shopping Cart: 1 item(s)")
# # You can add one new item at a time:
# assert(m3.addItem('milk') == False) # Return False if the item is already present
# assert(m3.addItem('eggs') == True) # Return True if we added a new item
# assert(m3.itemCount() == 2)
# assert(m3.getItems() == {'milk', 'eggs'})
# assert((m3.getItems() == m1.getItems()) and (m3.getItems != m2.getItems()))
# # Once more, but with a new item:
# assert(m3.addItem('water') == True) # True means the item was added!
# # and so these all change:
# assert(m3.itemCount() == 3)
# assert(m3.getItems() == {'milk', 'eggs','water'})
# # Lastly, all carts start out open
# assert(m1.status == 'open')
# # ...unless you pay them
# m1.checkout()
# assert(m1.status == 'closed')
# m1.checkout()
# assert(m1.status == 'closed') # still closed
# # and you cannot add any more items
# assert(m1.addItem('tomatoes') == False) # Return False if the cart has been checked out
# assert(m1.status == 'closed') # still closed
# w1 = WishList("LEMON")
# assert(str(w1) == "Wish List: 1 item(s)")
# assert(w1.itemCount() == 1)
# assert(w1.getItems() == {'lemon'})
# assert(w1.addItem("Salt") == True)
# assert(w1.getItems() == {'lemon', 'salt'})
# assert(w1.status == 'open')
# w1.checkout() # does nothing, the wish list stays open
# assert(w1.status == 'open')

# print("PASSED")


# def  findFlukeNumbers(L):
#     newD = {}
#     newS = set()
#     for i in L:        
#         if isinstance(i, int):
#             if i not in newD:
#                 newD[i] = 1
#             else:
#                 newD[i] +=1
#     for x in newD:
#             if x == newD[x]:
#                 newS.add(x)
#     return newS

# assert(findFlukeNumbers([1,'a','a',[4], 3, False, 3, 3]) == {1, 3})
# assert(findFlukeNumbers([1, 2, 2, 3, 3, 3, 4]) == {1, 2, 3})
# assert(findFlukeNumbers([0, False, 'hello']) == set())
# print("PASSED")
# import random
# import math
# from cmu_112_graphics import *

# def appStarted(app):
#     app.gameState = "playing"
#     app.cr = 10
#     app.recLen = 30
#     app.recX = random.randint(0,370)
#     app.recY = random.randint(0,370)
#     app.circles = []
#     for i in range(20):
#         tup = (random.randint(0,390),random.randint(0,390))
#         app.circles.append(tup)

# def keyPressed(app,event):
#     if event.key == "r":
#         appStarted(app)

# def mousePressed(app,event):
#     app.recX = event.x
#     app.recY = event.y

# def distance(x0,y0,x1,y1):
#     return math.sqrt((x1-x0)**2+(y1-y0)**2)

# def timerFired(app):
#     for i in app.circles:
#         d = distance(app.recX,app.recY, i[0],i[1])
#         if d <= app.recLen:
#             app.circles.remove(i)
#     if len(app.circles) == 0:
#         app.gameState = "won"
    

# def redrawAll(app,canvas):
#     if app.gameState == "playing":
#         canvas.create_rectangle(app.recX-app.recLen,app.recY-app.recLen,app.recX + app.recLen, app.recY + app.recLen, fill = "red")
#         for x in app.circles:
#             canvas.create_oval(x[0]-app.cr,x[1]-app.cr,x[0]+app.cr,x[1]+app.cr, fill = "blue" )
#     elif app.gameState == "won":
#         canvas.create_text(app.width//2,app.height//2, text = "YOU WIN", font = 20)
# runApp(width=400, height=400)

# def mergeSorted(l1, l2):
#     if len(l1) == 0:
#         return l2
#     elif len(l2) == 0:
#         return l1
#     elif l1[0] < l2[0]:
#         return [l1[0]] + mergeSorted(l1[1:], l2)
#     else:
#         return [l2[0]] + mergeSorted(l1, l2[1:])

# L1 = [1,5,6]
# L2 = [3,4]
# assert(mergeSorted([1,5,6], [3,4]) == [1,3,4,5,6])
# assert(mergeSorted([2,4], [1,3,5]) == [1,2,3,4,5])
# assert(mergeSorted([7,8], [1,2,3,4]) == [1,2,3,4,7,8])
# assert(mergeSorted([], [1,6]) == [1,6])
# assert(mergeSorted([], []) == [])
# assert(mergeSorted([8], []) == [8])
# print("trurr")


def onlyDigits(L):
    if len(L) == 0:
        return []
    else:
            if helper(L[0]) == []:
                 return [0] + [onlyDigits(L[1:])]
            else:
                 return [helper(L[0])] + onlyDigits(L[1:])


def helper(n, l = []):
    if n == 0:
        return l
    else:
        mod = n%10
        if mod %2 == 1:
            l.append(mod)
        n = n//10
        return helper(n,l)
    
print(onlyDigits([43, 23265, 28,58344]))
        
