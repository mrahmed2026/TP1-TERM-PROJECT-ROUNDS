from pygame.locals import *
import pygame, sys
import button
import csv
from main_game import maingame
from difficulty_menu import difficulty
import os
from get_path import getPath
path = getPath()


def levelEditor():
    # Initialize Pygame
    mainClock = pygame.time.Clock()
    pygame.init()
    pygame.display.set_caption('game base')
    mapLevel = 4
    title_font = pygame.font.SysFont('Arial', 50)
    monitor_size = [pygame.display.Info().current_w, pygame.display.Info().current_h]
    screen = pygame.display.set_mode(monitor_size, pygame.FULLSCREEN)
    gridRows = 17
    gridCols = 29
    tileSize = monitor_size[1] // 20
    tileTypes = 10
    panelStart = monitor_size[0]-288
    buttonSelected = 0
    # the data to create the map.
    roundsMapData = []
    # populate the map data LIST with -1, throught, as -1 means no tile.
    # so map starts off empty.
    for row in range(gridRows):
        r = [-1]* gridCols
        roundsMapData.append(r)

    # making the map viable, by ensuring there is a ground.
    for tile in range(gridCols):
        roundsMapData[-1][tile] = 0
        roundsMapData[-2][tile] = 0


    # load and scale bg image
    bg_img = pygame.image.load(f"{path}images/rounds_bg_image.jpg")
    bg_img = pygame.transform.scale(bg_img,(monitor_size[0],monitor_size[1]-131))

    # load different tile images into a list.
    tilesList = []
    for i in range(tileTypes):
        img = pygame.image.load(f"{path}tiles/{i}.png")
        img = pygame.transform.scale(img, (tileSize,tileSize))
        tilesList.append(img)
    save_map_img = pygame.image.load(f"{path}buttons/save_map_button.png")
    load_map_img = pygame.image.load(f"{path}buttons/load_map_button.png")
    play_map_img = pygame.image.load(f"{path}buttons/play_map_button.png")


    def drawGrid():
        # vertical lines
        for c in range(gridCols+1):
            pygame.draw.line(screen, (255,255,255), (c*tileSize, (tileSize*5)), (c*tileSize,monitor_size[1]-131))
        # horizontal lines
        for r in range(gridRows+1):
            pygame.draw.line(screen, (255,255,255), (0, r*tileSize + (tileSize*5)), (monitor_size[0], r*tileSize + (tileSize*5)))

    # create tile buttons for editor, each row has 3 buttons.
    buttonList = []
    buttonCols = 0
    buttonRows = 0
    for i in tilesList:
        tileButton = button.Button(panelStart + (75*buttonCols)+50, (87*buttonRows)+65 , i, 1)
        buttonList.append(tileButton)
        buttonCols+=1
        if buttonCols == 3:
            buttonRows+=1
            buttonCols = 0

    save_map_button = button.Button((monitor_size[0]//2)/2, monitor_size[1]-65,save_map_img,0.3)
    load_map_button = button.Button(monitor_size[0]//2 -100, monitor_size[1]-65,load_map_img,0.3)
    play_map_button =button.Button(monitor_size[0]//2 +200, monitor_size[1]-65,play_map_img,0.3)

        
    def populateMap ():
        for row in range(5,len(roundsMapData)):
            for tile in range(len(roundsMapData[row])):
                if roundsMapData[row][tile] >= 0:
                    screen.blit(tilesList[roundsMapData[row][tile]], (tile*tileSize, row*tileSize))





    # Main game loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if event.key == K_UP:
                    mapLevel += 1
                    roundsMapData = []
                    for row in range(gridRows):
                        r = [-1]* gridCols
                        roundsMapData.append(r)
                    # making the map viable, by ensuring there is a ground.
                    for tile in range(gridCols):
                        roundsMapData[-1][tile] = 0
                        roundsMapData[-2][tile] = 0
                if event.key == K_DOWN:
                    if mapLevel > 4:
                        mapLevel -= 1

        screen.fill((255,255,255))
        screen.blit(bg_img,(0,0))
        drawGrid()
        # draw tile panel
        pygame.draw.rect(screen, (255,255,255), (panelStart,0, monitor_size[0],monitor_size[1]))


        if save_map_button.draw(screen):
            with open (f"{path}level{mapLevel}.csv", "w", newline = "") as csvFile:
                writer = csv.writer(csvFile, delimiter = ",")
                for row in roundsMapData:
                    writer.writerow(row)
        if load_map_button.draw(screen):
            filePath = f"{path}level{mapLevel}.csv"
            if os.path.isfile(filePath):
                with open (f"{path}level{mapLevel}.csv", newline = "") as csvFile:
                    reader = csv.reader(csvFile, delimiter = ",")
                    # had to learn how to use enumerate here, as the range(len)
                    # function was not a viable way to iterate through the csv file
                    for x, row in enumerate (reader):
                        for tile in range(len(row)):
                            roundsMapData[x][tile] = int(row[tile]) 

        if play_map_button.draw(screen):
            with open (f"{path}level{mapLevel}.csv", "w", newline = "") as csvFile:
                writer = csv.writer(csvFile, delimiter = ",")
                for row in roundsMapData:
                    writer.writerow(row)
            d = difficulty()
            maingame(d, mapLevel)




        title_label = title_font.render(f"Map Level {mapLevel}", True, (0, 0, 0))
        screen.blit(title_label, (monitor_size[0]-150 - title_label.get_width()//2, monitor_size[1]-80))
        # drawring my buttons onto the tile panel.
        for i in range(len(buttonList)):
            if buttonList[i].draw(screen):
                buttonSelected = i
        # highlight the selected tile button red.
        if buttonSelected != None:
            pygame.draw.rect(screen, (255,0,0), buttonList[buttonSelected].rect,3)

        populateMap()


        pos = pygame.mouse.get_pos()
        cx = pos[0]//tileSize
        cy = pos[1]//tileSize
        if pos[0]< panelStart and pos[1]< (tileSize*17) and pos[1] > (tileSize*5):
            # now we can look for mouse clicks in bounds of the grid.
            # update the tile value.
            if pygame.mouse.get_pressed()[0] == 1:
                if roundsMapData[cy][cx] != buttonSelected:
                    roundsMapData[cy][cx] = buttonSelected
            if pygame.mouse.get_pressed()[2] == 1:
                    roundsMapData[cy][cx] = -1


        pygame.display.update()
