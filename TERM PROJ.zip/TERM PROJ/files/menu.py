import pygame
import sys
from pygame.locals import *
from main_game import maingame

# Initialize Pygame
pygame.init()

# Set up the display
monitor_size = [pygame.display.Info().current_w, pygame.display.Info().current_h]
screen = pygame.display.set_mode(monitor_size, pygame.FULLSCREEN)
pygame.display.set_caption('Menu')

# Set up the clock
clock = pygame.time.Clock()

# Define the menu options
MENU_OPTIONS = [
    ('Start', 'start_game'),
    ('Credits', 'show_credits'),
    ('Exit', 'quit_game')
]

# Define the font and font size for the menu options
MENU_FONT = pygame.font.Font(None, 80)

def draw_menu():
    # Clear the screen
    screen.fill((255, 255, 255))

    # Draw the menu options
    for i, (label, _) in enumerate(MENU_OPTIONS):
        text = MENU_FONT.render(label, True, (0, 0, 0))
        text_rect = text.get_rect(center=(monitor_size[0]//2, monitor_size[1]//2 + i * 50))
        screen.blit(text, text_rect)

def handle_menu_input():
    for event in pygame.event.get():
        if event.type == QUIT:
            quit_game()
        elif event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                quit_game()
        elif event.type == MOUSEBUTTONDOWN and event.button == 1:
            # Get the mouse position
            mouse_pos = pygame.mouse.get_pos()

            # Check which menu option was clicked
            for label, action in MENU_OPTIONS:
                text = MENU_FONT.render(label, True, (0, 0, 0))
                text_rect = text.get_rect(center=(monitor_size[0]//2, monitor_size[1]//2 + MENU_OPTIONS.index((label, action)) * 50))
                if text_rect.collidepoint(mouse_pos):
                    if action == 'start_game':
                        start_game()
                    elif action == 'show_credits':
                        show_credits()
                    elif action == 'quit_game':
                        quit_game()


def start_game():
    maingame()
def show_credits():
    # Clear the screen
    screen.fill((255, 255, 255))

    # Define the font and font size for the credits text
    CREDITS_FONT = pygame.font.Font(None, 80)

    # Render the "created by" text and blit it to the center of the screen
    created_by_text = CREDITS_FONT.render('Created by Your Name', True, (0, 0, 0))
    created_by_rect = created_by_text.get_rect(center=(monitor_size[0]//2, monitor_size[1]//2 - 50))
    screen.blit(created_by_text, created_by_rect)

    # Render the "thank you" text and blit it to the center of the screen
    thank_you_text = CREDITS_FONT.render('Thank you for playing!', True, (0, 0, 0))
    thank_you_rect = thank_you_text.get_rect(center=(monitor_size[0]//2, monitor_size[1]//2 + 50))
    screen.blit(thank_you_text, thank_you_rect)

    # Update the screen
    pygame.display.update()

    # Wait for a few seconds before returning to the menu
    pygame.time.wait(3000)


def quit_game():
    pygame.quit()
    sys.exit()

# Start the menu loop
while True:
    # Handle menu input
    handle_menu_input()

    # Draw the menu
    draw_menu()

    # Update the screen
    pygame.display.update()

    # Limit the frame rate
    clock.tick(60)
