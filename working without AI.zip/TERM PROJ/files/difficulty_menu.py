from pygame.locals import *
import pygame, sys
import button
from main_game import maingame
path = "D:/Semester 2/15112/Spring semester 15112/TERM PROJ/"

def difficulty():
    # Initialize Pygame
    pygame.init()
    pygame.display.set_caption('game base')
    monitor_size = [pygame.display.Info().current_w, pygame.display.Info().current_h]
    screen = pygame.display.set_mode(monitor_size, pygame.FULLSCREEN)
    
    # Font
    title_font = pygame.font.SysFont('Arial', 100)

    # Images
    easy_img = pygame.image.load(f"{path}buttons/easy_button.png")
    medium_img = pygame.image.load(f"{path}buttons/medium_button.png")
    hard_img = pygame.image.load(f"{path}buttons/hard_button.png")

    # Buttons
    easy_button = button.Button(monitor_size[0]//2,(monitor_size[1]//2)-100,easy_img,0.5)
    medium_button = button.Button(monitor_size[0]//2,(monitor_size[1]//2)+100,medium_img,0.5)
    hard_button = button.Button(monitor_size[0]//2,(monitor_size[1]//2)+300,hard_img,0.5)


    # Main game loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
        screen.fill((255,255,255))
        # Render title label and display it on the top of the screen
        title_label = title_font.render("SELECT DIFFICULTY LEVEL", True, (0, 0, 0))
        screen.blit(title_label, (monitor_size[0]//2 - title_label.get_width()//2, 50))
        # Draw buttons and check for input
        if easy_button.draw(screen):
            return "easy"
        if medium_button.draw(screen):
            return "medium"
        if hard_button.draw(screen):
            return "hard"

        pygame.display.update()
