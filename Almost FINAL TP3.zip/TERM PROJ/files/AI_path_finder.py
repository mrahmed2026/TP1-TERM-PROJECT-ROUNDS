from pathfinding.core.grid import Grid
from pathfinding.finder.a_star import AStarFinder
import csv
worldGrid = []
from get_path import getPath
path2 = getPath()

def findShortestPath(mapLevel, x1,y1,x2,y2):
    # reading in THE MAP DATA FROM THE CSV FILE 
    with open (f"{path2}level{mapLevel}.csv", newline = "") as csvFile:
        reader = csv.reader(csvFile, delimiter = ",")
        # had to learn how to use enumerate here, as the range(len)
        # function was not a viable way to iterate through the csv file
        for x, row in enumerate(reader):
            l = []
            for tile in range(len(row)):
                if int(row[tile]) == -1:
                    l.append(1)  # obstacle value
                else:
                    l.append(-1)  # high cost for non-obstacle tile
            worldGrid.append(l)


    grid = Grid(matrix=worldGrid)
    start = grid.node(y1,x1)
    end = grid.node(y2,x2)
    # col number, row number
    finder = AStarFinder()

    path, runs = finder.find_path(start, end, grid)
    for i in range(len(path)):
        path[i] = (path[i][1],path[i][0])
    return path





