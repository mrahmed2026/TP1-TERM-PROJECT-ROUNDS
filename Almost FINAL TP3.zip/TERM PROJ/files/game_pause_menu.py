from pygame.locals import *
from get_path import getPath
path = getPath()

def pause_menu():
    import pygame, sys
    import button
    from main_game import maingame
    from start_menu import start

    # Initialize Pygame
    mainClock = pygame.time.Clock()
    pygame.init()
    pygame.display.set_caption('game base')
    monitor_size = [pygame.display.Info().current_w, pygame.display.Info().current_h]
    screen = pygame.display.set_mode(monitor_size, pygame.FULLSCREEN)
    # images
    resume_img = pygame.image.load(f"{path}buttons/resume_button.png")
    main_menu_img = pygame.image.load(f"{path}buttons/main_menu_button.png")
    # buttons
    resume_button = button.Button(monitor_size[0]//2,(monitor_size[1]//2)-200,resume_img,0.5)
    main_menu_button = button.Button(monitor_size[0]//2,(monitor_size[1]//2)+20,main_menu_img,0.5)


    # Main game loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        screen.fill((255,255,255))
        if resume_button.draw(screen) == True:
                pygame.time.wait(500) # add a small delay
                return True
        if main_menu_button.draw(screen) == True:
            pygame.time.wait(500) # add a small delay
            start()
        pygame.display.update()

