from pygame.locals import *
import pygame, sys
import button
from main_game import maingame
from difficulty_menu import difficulty
from level_editor import levelEditor
from get_path import getPath
path = getPath()
# Initialize Pygame
mainClock = pygame.time.Clock()
pygame.init()
pygame.display.set_caption('game base')
monitorSize = [pygame.display.Info().current_w, pygame.display.Info().current_h]
screen = pygame.display.set_mode(monitorSize, pygame.FULLSCREEN)
def start():
    # images
    startImg = pygame.image.load(f"{path}buttons/start_button.png")
    creditImg = pygame.image.load(f"{path}buttons/credits_button.png")
    exitImg = pygame.image.load(f"{path}buttons/exit_button.png")
    difficultyLevelImg = pygame.image.load(f"{path}buttons/difficulty_button.png")
    levelEditorImg = pygame.image.load(f"{path}buttons/level_editor_button.png")

    # buttons
    startButton = button.Button(monitorSize[0]//2,(90),startImg,0.5)
    levelEditorButton = button.Button(monitorSize[0]//2,(265),levelEditorImg,0.5)
    difficultyLevelButton = button.Button(monitorSize[0]//2,(monitorSize[1]//2),difficultyLevelImg,0.5)
    creditsButton = button.Button(monitorSize[0]//2,(monitorSize[1]//2)+175,creditImg,0.5)
    exitButton = button.Button(monitorSize[0]//2,(monitorSize[1]//2)+350,exitImg,0.5)




    # Main game loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
        screen.fill((255,255,255))
        if startButton.draw(screen):
            maingame("easy")
        if difficultyLevelButton.draw(screen) == True:
            pygame.time.wait(200) # add a small delay
            screen.fill((255, 255, 255))
            d = difficulty()
            maingame(d)
            pygame.display.update()
        if  levelEditorButton.draw(screen):
            levelEditor()
        if creditsButton.draw(screen):
            # Clear the screen
            screen.fill((255, 255, 255))

            # Define the font and font size for the credits text
            creditFont = pygame.font.Font(None, 80)

            # Render the "created by" text and blit it to the center of the screen
            createdByText = creditFont.render('Created by Rayyan Ahmed', True, (0, 0, 0))
            createdByRect = createdByText.get_rect(center=(monitorSize[0]//2, monitorSize[1]//2 - 50))
            screen.blit(createdByText, createdByRect)

            # Render the "thank you" text and blit it to the center of the screen
            thankYouText = creditFont.render('Thank you for playing!', True, (0, 0, 0))
            thankYouRect = thankYouText.get_rect(center=(monitorSize[0]//2, monitorSize[1]//2 + 50))
            screen.blit(thankYouText, thankYouRect)
            # Update the screen
            pygame.display.update()

            # Wait for a few seconds before returning to the menu
            pygame.time.wait(3000)
        if exitButton.draw(screen) == True:
            pygame.quit()
            sys.exit()
        pygame.display.update()