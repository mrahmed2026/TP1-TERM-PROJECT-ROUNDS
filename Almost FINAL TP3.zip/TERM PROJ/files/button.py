import pygame
import sys
from pygame.locals import *


# button class

class Button():
    def __init__(self, x,y,image,scale):
         imageWidth = image.get_width()
         imageHeight = image.get_height()
         self.image = pygame.transform.scale(image, (int(imageWidth*scale),int(imageHeight*scale)))
         self.rect = self.image.get_rect()
         self.rect.center = (x,y)
         self.clicked = False
    
    def draw(self,screen):
        action = False
        # get mouse position
        pos = pygame.mouse.get_pos()
        # check if mouse is over one of the buttons
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                 self.clicked = True
                 action = True
        if pygame.mouse.get_pressed()[0] == 0:
                self.clicked = False                 
        # draw button on the screen
        screen.blit(self.image, (self.rect.x,self.rect.y))
        return action

    



