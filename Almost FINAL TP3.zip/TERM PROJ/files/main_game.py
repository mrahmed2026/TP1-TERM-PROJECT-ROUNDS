from pygame.locals import *
import os
from get_path import getPath
path = getPath()
def maingame(difficulty = "easy", mapLevel = None):
    import pygame, sys, csv
    from blade import SawBlade
    from game_pause_menu import pause_menu
    from game_over_menu import gameover
    from game_won import gamewon
    from AI_path_finder import findShortestPath
    import simpleaudio as sa
    import time
    gunShot = sa.WaveObject.from_wave_file(f'{path}gunshot.wav')
    # Initialize Pygame
    mainClock = pygame.time.Clock()
    pygame.init()
    pygame.display.set_caption('game base')
    monitor_size = [pygame.display.Info().current_w, pygame.display.Info().current_h]
    screen = pygame.display.set_mode(monitor_size, pygame.FULLSCREEN)
    background_image = pygame.image.load(f"{path}images/rounds_bg_image.jpg")
    background_image = pygame.transform.scale(background_image, monitor_size)
    # csvDataList is a list with the data from the csv file
    csvDataList = []
    # tilesTypes is the number of tiles there are.
    tileTypes = 10
    # tileSize is the size of each tile
    tileSize = (monitor_size[0]//28, monitor_size[1]//17)
    # tilesList is a list with every tile and its attributes
    tilesList = []
    # tilesImgList is a list with every tileImg scaled to fit the screen
    tilesImgList = []
    # FIND ROW AND COL FOR SCREEN SIZE FULL SCREEN
    spriteSheetPath = f"{path}TeamGunner_By_SecretHideout_060519/TeamGunner_By_SecretHideout_060519/CHARACTER_SPRITES/"
    fps = 60



    # Create two saw blades with different positions and scales
    blade1 = SawBlade(f"{path}blade gif", (300, 300), (0,0))
    blade2 = SawBlade(f"{path}blade gif", (300, 300), (monitor_size[0]-300, 0))
    paused = False
    if difficulty == "easy" and mapLevel == None:
        mapLevel = 1
    if difficulty == "medium" and mapLevel == None:
        mapLevel = 2
    if difficulty == "hard" and mapLevel == None:
        mapLevel = 3

    # reading in THE MAP DATA FROM THE CSV FILE 
    with open (f"{path}level{mapLevel}.csv", newline = "") as csvFile:
        reader = csv.reader(csvFile, delimiter = ",")
        # had to learn how to use enumerate here, as the range(len)
        # function was not a viable way to iterate through the csv file
        for x, row in enumerate (reader):
            l = []
            for tile in range(len(row)):
                l.append(int(row[tile]))
            csvDataList.append(l)


    # load different tile images into a list.
    # and scale each image
    for i in range(tileTypes):
        img = pygame.image.load(f"{path}tiles/{i}.png")
        img = pygame.transform.scale(img, (tileSize[0],tileSize[1]))
        tilesImgList.append(img)
    # creating a list with tuples
    # where each tuple contains the image, its position, its rect and its mask
    # and then finally its postion in the csv file in regards to 
    # row then column.
    for row in range(len(csvDataList)):
        for tile in range(len(csvDataList[row])):
            if csvDataList[row][tile] >= 0:
                img = tilesImgList[csvDataList[row][tile]]
                imgRec = img.get_rect()
                imgRec.x = tile*tileSize[0]
                imgRec.y = row*tileSize[1] 
                imgMask = pygame.mask.from_surface(img)
                tilesList.append((img, (tile*tileSize[0],
                                     row*tileSize[1]), imgRec, imgMask, (row, tile) ))


    def extractSpriteSheet(spriteSheet, frame,width, height, scale):
        spriteImage = pygame.Surface((width, height))
        spriteImage.blit(spriteSheet, (0,0), (frame*(8+width),3,width,height))
        spriteImage = pygame.transform.scale(spriteImage,
                                            (width*scale[0], height*scale[1]))
        spriteImage.set_colorkey((0,0,0))
        return spriteImage

    def imageList(imgPath,colour):
            spriteImg = pygame.image.load(
                f"{spriteSheetPath}{colour}/Gunner_{colour}_{imgPath}")
            l = []
            for frame in range(spriteImg.get_width()//48):
                image = extractSpriteSheet(spriteImg, frame, 40,35, (2.7,2.7))
                l.append(image)
            return l
    
    def flippedImages(l):
        for i in range(len(l)):
            img = pygame.transform.flip(l[i], True, False)
            l[i] = img
        return l
    
    import math

    class Bullet(pygame.sprite.Sprite):
        def __init__(self, x, y, mouse_x, mouse_y):
            pygame.sprite.Sprite.__init__(self)
            self.speed = 15
            self.image = pygame.image.load(f"{path}images/bullet_image.png")
            self.image = pygame.transform.scale(self.image, (35,35))
            self.rect = self.image.get_rect()
            self.rect.center = (x,y)
            self.direction = math.atan2(mouse_y - y, mouse_x - x)
            # convert the direction to degrees and rotate the image accordingly
            self.image = pygame.transform.rotate(self.image, -math.degrees(self.direction))
            self.mask = pygame.mask.from_surface(self.image)
        def update(self):
            # move the bullet in the direction calculated in __init__
            self.rect.x += self.speed * (math.cos(self.direction)*7)
            self.rect.y += self.speed * (math.sin(self.direction)*7)
            # checking if bullet goes off screen. so i can kill it 
            # and remove it from memory.
            if self.rect.right < 0 or self.rect.left > monitor_size[0] or \
            self.rect.bottom < 0 or self.rect.top > monitor_size[1]:
                self.kill()

    playerBulletGroup = pygame.sprite.Group()
    enemyBulletGroup = pygame.sprite.Group()



    
    class Player(pygame.sprite.Sprite):
        def __init__ (self, x, y, colour, user):
            super().__init__()
            self.crouchList = imageList("Crouch.png", colour)
            self.deathList = imageList("Death.png", colour)
            self.idleList = imageList("Idle.png", colour)
            self.jumpList = imageList("Jump.png", colour)
            self.runList = imageList("Run.png", colour)
            self.runListLeft = flippedImages(self.runList.copy())
            self.idleListLeft = flippedImages(self.idleList.copy())
            self.crouchListLeft = flippedImages(self.crouchList.copy())
            self.jumpListLeft = flippedImages(self.jumpList.copy())
            self.deathListLeft = flippedImages(self.deathList.copy())
            self.user = user

            # self.direction is a variable that lets me know if i am moving
            # left (False) or moving right (True)
            self.direction = True
            # self.index lets me know what image im at in the list
            self.index = 0
            # self. count allows me to make the animation transition smoother
            self.counter = 0
            self.image = self.idleList[self.index]
            self.rect = self.image.get_rect()
            self.width = self.image.get_width()
            self.height = self.image.get_height()
            self.rect.x = x
            self.rect.y = y
            self.velocityY = 0
            self.kill = False  
            self.health = 100
            self.jumped = False 
            self.shoot = False
            self.canShoot = True
            self.actionTime = 0
            self.var = 0
            self.hitTop = False

        def lineMove(self, screen):
            # Calculate the start and end points of the line based on the current position of the sprite and var
            if self.user == "player":
                if self.direction:
                    self.startPoint = (self.rect.centerx + (self.width * 0.6), self.rect.centery)
                    if self.var < 100:
                        self.endPoint = (self.startPoint[0] + 300, self.startPoint[1] + self.var)
                    else:
                        self.endPoint = (self.startPoint[0] + 300, self.startPoint[1] + (200 - self.var))
                else:
                    self.startPoint = (self.rect.centerx - (self.width * 0.6), self.rect.centery)
                    if self.var < 100:
                        self.endPoint = (self.startPoint[0] - 300, self.startPoint[1] + self.var)
                    else:
                        self.endPoint = (self.startPoint[0] - 300, self.startPoint[1] + (200 - self.var))
            if self.user == "AI":
                if self.direction ==  False:
                    self.startPoint = (self.rect.centerx + (self.width * 0.6), self.rect.centery)
                    if self.var < 100:
                        self.endPoint = (self.startPoint[0] + 300, self.startPoint[1] + self.var)
                    else:
                        self.endPoint = (self.startPoint[0] + 300, self.startPoint[1] + (200 - self.var))
                else:
                    self.startPoint = (self.rect.centerx - (self.width * 0.6), self.rect.centery)
                    if self.var < 100:
                        self.endPoint = (self.startPoint[0] - 300, self.startPoint[1] + self.var)
                    else:
                        self.endPoint = (self.startPoint[0] - 300, self.startPoint[1] + (200 - self.var))

            # Draw the line on the screen
            pygame.draw.line(screen, (255, 0, 0), self.startPoint, self.endPoint, 5)


        def update(self):
            # calculate new player position
            # check collisions at new position
            # move player to position
            # delta x is change in distant in x axis
            dx = 0
            # delta y is change in distant in y axis
            dy = 0 
            # walk cooldown allows me to make sure that i dont iterate
            # too fast through my running list.
            if self.var == -102 and self.hitTop == True:
                self.hitTop = False
            if self.var == 300:
                self.hitTop = True
            
            if self.hitTop == False:
                self.var += 3

            if self.hitTop:
                self.var -= 3


            walkCooldown = 5
            key = pygame.key.get_pressed()
            if (key[pygame.K_a] and self.user == "player") or (key[pygame.K_LEFT] and self.user == "AI"):
                if self.user == "player":
                    self.direction = False
                else:
                    self.direction = True
                dx -= 5
                self.counter += 1

            if (key[pygame.K_d] and self.user == "player") or (key[pygame.K_RIGHT] and self.user == "AI"):
                if self.user == "player":
                    self.direction = True
                else:
                    self.direction = False
                dx += 5
                self.counter += 1


            # WHEN CHARACRER IS IDLE

            if (key[pygame.K_d] == False and key[pygame.K_a] == False\
                  and self.kill == False and key[pygame.K_s] == False and self.user == "player") or\
                (key[pygame.K_RIGHT] == False and key[pygame.K_LEFT] == False\
                  and self.kill == False and key[pygame.K_DOWN] == False and self.user == "AI")    :
                self.counter = 0 
                self.index = 0
                if (self.direction == True and self.user == "player") or (self.direction == False and self.user == "AI"):
                    self.image = self.idleList[self.index]
                elif (self.direction == False and self.user == "player") or (self.direction == True and self.user == "AI"):
                    self.image = self.idleListLeft[self.index]

            if (key[pygame.K_w] and self.jumped == False and self.user == "player") or \
                (key[pygame.K_UP] and self.jumped == False and self.user == "AI"):
                self.velocityY -= 35
                self.jumped = True

            if (key[pygame.K_w] == False and self.user == "player") or (key[pygame.K_UP] == False and self.user == "AI") :
                self.jumped = False

            if  (key[pygame.K_SPACE] and self.user == "player" and self.canShoot == True)or (key[pygame.K_RALT] and self.user == "AI" and self.canShoot == True):
                self.canShoot = False
                self.shoot = True
            if  (key[pygame.K_SPACE] == False and self.user == "player") or (key[pygame.K_RALT] == False and self.user == "AI"):
                self.shoot = False
            if (key[pygame.K_s] and self.user == "player") or (key[pygame.K_DOWN] and self.user == "AI"):
                if (self.direction == True and self.user == "player") or (self.direction == False and self.user == "AI"):
                            self.image = self.crouchList[2]
                if (self.direction == False and self.user == "player") or (self.direction == True and self.user == "AI"):
                            self.image = self.crouchListLeft[2]

            # ANIMATIONS

            if self.counter >= walkCooldown:
                self.counter = 0
                self.index += 1
                if self.kill == False: 
                    if (key[pygame.K_d] or  key[pygame.K_a]) and self.user == "player":
                        if self.index >= len(self.runList):
                            self.index = 0
                        if self.direction == True:
                            self.image = self.runList[self.index]
                        if self.direction == False:
                            self.image = self.runListLeft[self.index]
                    if (key[pygame.K_RIGHT] or  key[pygame.K_LEFT]) and self.user == "AI":
                        if self.index >= len(self.runList):
                            self.index = 0
                        if self.direction == False:
                            self.image = self.runList[self.index]
                        if self.direction == True:
                            self.image = self.runListLeft[self.index]

                
            
            #gravity mechanics
            self.velocityY+= 1
            if self.velocityY > 20:
                self.velocityY = 20
            dy+= self.velocityY


            # CHECKING FOR COLLISIONS
            if self.rect.bottom >= monitor_size[1]:
                self.rect.bottom = monitor_size[1]
            if self.rect.top <= 0:
                self.rect.top = 0
                self.velocityY = 0
            if self.rect.left + dx < 0:
                dx = 0 - self.rect.left
            if self.rect.right + dx > monitor_size[0]:
                dx = monitor_size[0] - self.rect.right 

            for i in tilesList:
                tileRect = i[2]
                tileWidth = i[0].get_width()
                tileHeight = i[0].get_height()
                if playerBulletGroup:
                    for sprite in playerBulletGroup:
                        if sprite.rect.colliderect(i[2]):
                            # collision detected!
                            playerBulletGroup.remove(sprite)
                if enemyBulletGroup:
                    for sprite in enemyBulletGroup:
                        if sprite.rect.colliderect(i[2]):
                            # collision detected!
                            enemyBulletGroup.remove(sprite)

                # check for collision in the y axis
                if tileRect.colliderect(self.rect.x, self.rect.y + dy,
                                         self.width, self.height):
                    # check if player is below the ground
                    # so if the player is jumping.
                    if self.velocityY < 0 :
                        dy = tileRect.bottom - self.rect.top
                        self.velocityY = 0
                    # checking if player is above the ground, so falling
                    elif self.velocityY >= 0 :
                        dy = tileRect.top - self.rect.bottom
                        self.velocityY = 0
                    self.collidedTile = tilesList.index(i)


                # check for collision in the x axis
                elif tileRect.colliderect(self.rect.x + dx, self.rect.y,
                                         self.width, self.height):
                    dx = 0
                    self.collidedTile = tilesList.index(i)
            # check for pixel perfect collision with saw blades
            self.mask = pygame.mask.from_surface(self.image)
            if self.mask.overlap(blade1.mask, (blade1.rect.x - self.rect.x, blade1.rect.y - self.rect.y)) or \
                self.mask.overlap(blade2.mask, (blade2.rect.x - self.rect.x, blade2.rect.y - self.rect.y)):
                self.health -= 0.5
            if self.user == "AI" and playerBulletGroup:
                if pygame.sprite.spritecollide(self, playerBulletGroup,True,pygame.sprite.collide_mask): 
                    if difficulty == "easy":
                        self.health -= 20
                    elif difficulty == "medium":
                        self.health -= 12
                    elif difficulty == "hard":
                        self.health -= 8
            if self.user == "player" and enemyBulletGroup:
                if pygame.sprite.spritecollide(self, enemyBulletGroup,True,pygame.sprite.collide_mask): 
                    if difficulty == "easy":
                        self.health -= 20
                    elif difficulty == "medium":
                        self.health -= 12
                    elif difficulty == "hard":
                        self.health -= 8


            # UPDATED POSITION
            self.rect.x += dx
            self.rect.y += dy
            healthBar(self.health, self.rect.x + 15, self.rect.y-15)
            if self.health <= 0 :
                self.kill = True
            if self.shoot == True and self.user == "player":
                    if self.direction == True:
                        playerBullet = Bullet(self.rect.centerx + (self.width * 0.6),
                        self.rect.centery, self.endPoint[0], self.endPoint[1] )
                    else:
                        playerBullet = Bullet(self.rect.centerx - (self.width * 0.6),
                        self.rect.centery, self.endPoint[0], self.endPoint[1] )

                    gunShot.play()

                    playerBulletGroup.add(playerBullet)
                    self.shoot = False
            if self.shoot == True and self.user == "AI":
                    if self.direction == True:
                        enemyBullet = Bullet(self.rect.centerx - (self.width * 0.6),
                        self.rect.centery, self.endPoint[0], self.endPoint[1] )
                    else:
                        enemyBullet = Bullet(self.rect.centerx + (self.width * 0.6),
                        self.rect.centery, self.endPoint[0], self.endPoint[1] )

                    gunShot.play()

                    enemyBulletGroup.add(enemyBullet)
                    self.shoot = False


            screen.blit(self.image, self.rect)
            if self.kill == True and self.user == "player":
                gameover()
            elif self.kill == True and self.user == "AI":
                gamewon(difficulty,mapLevel)


            #pygame.draw.rect(screen, (255,255,255), self.rect, 2)
            



    player = Player(250, monitor_size [1]- 223, "Red", "player")
    
    def healthBar(health, x, y):
        ratio = health/100
        pygame.draw.rect(screen, (255,0,0) , (x,y, 100,10))
        pygame.draw.rect(screen, (0,255,0) , (x,y, 100*ratio,10))

    enemy = Player(monitor_size[0]-400, monitor_size[1]-223, "Black", "AI")

 
    # Main game loop
    while True:

        pos = pygame.mouse.get_pos()
        mainClock.tick(fps)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    # Toggle the paused variable when the Escape key is pressed
                    paused = not paused
                    if paused:
                        if pause_menu():
                            paused = False

# If the game is resumed, clear the screen and continue with the main game loop
        if paused == False:
            screen.blit(background_image, (0, 0))
            blade1.update()
            blade1.draw(screen)
            blade2.update()
            blade2.draw(screen)
           
            for i in tilesList:
                screen.blit(i[0],i[1])
                pygame.draw.rect(screen, (0,0,0), i[2], 2)
            
            playerBulletGroup.update()
            playerBulletGroup.draw(screen)
            enemyBulletGroup.update()
            enemyBulletGroup.draw(screen)
            player.update()
            enemy.update()
            if player.canShoot == False:
                player.actionTime +=1
                if player.actionTime >=30:
                    player.actionTime = 0
                    player.canShoot = True
            if enemy.canShoot == False:
                enemy.actionTime +=1
                if enemy.actionTime >=30:
                    enemy.actionTime = 0
                    enemy.canShoot = True

        player.lineMove(screen)
        enemy.lineMove(screen)
        #drawGrid()
        # Update the screen
        pygame.display.update()

