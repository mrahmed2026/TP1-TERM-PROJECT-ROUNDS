import pygame
print(pygame.version.ver)