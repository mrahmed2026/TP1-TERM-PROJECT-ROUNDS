count = 0
L = []
f = open("blade.py", "r")

for l in f:
  l = l.strip()
  if l and not l.startswith('#'):
      count += 1
L.append(count)
print(f,L)