# add a error message and clear screen when changing levels

from pygame.locals import *
import pygame, sys
import button
from main_game import maingame
from difficulty_menu import difficulty
from level_editor import levelEditor
path = "D:/Semester 2/15112/Spring semester 15112/TERM PROJ/"
# Initialize Pygame
mainClock = pygame.time.Clock()
pygame.init()
pygame.display.set_caption('game base')
monitor_size = [pygame.display.Info().current_w, pygame.display.Info().current_h]
screen = pygame.display.set_mode(monitor_size, pygame.FULLSCREEN)

# images
start_img = pygame.image.load(f"{path}buttons/start_button.png")
credit_img = pygame.image.load(f"{path}buttons/credits_button.png")
exit_img = pygame.image.load(f"{path}buttons/exit_button.png")
difficulty_level_img = pygame.image.load(f"{path}buttons/difficulty_button.png")
level_editor_img = pygame.image.load(f"{path}buttons/level_editor_button.png")

# buttons
start_button = button.Button(monitor_size[0]//2,(90),start_img,0.5)
level_editor_button = button.Button(monitor_size[0]//2,(265),level_editor_img,0.5)
difficulty_level_button = button.Button(monitor_size[0]//2,(monitor_size[1]//2),difficulty_level_img,0.5)
credits_button = button.Button(monitor_size[0]//2,(monitor_size[1]//2)+175,credit_img,0.5)
exit_button = button.Button(monitor_size[0]//2,(monitor_size[1]//2)+350,exit_img,0.5)




# Main game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                pygame.quit()
                sys.exit()
    screen.fill((255,255,255))
    if start_button.draw(screen):
        maingame("easy")
    if difficulty_level_button.draw(screen) == True:
        pygame.time.wait(200) # add a small delay
        screen.fill((255, 255, 255))
        difficulty()
        pygame.display.update()
    if  level_editor_button.draw(screen):
        levelEditor()
    if credits_button.draw(screen):
        # Clear the screen
        screen.fill((255, 255, 255))

        # Define the font and font size for the credits text
        CREDITS_FONT = pygame.font.Font(None, 80)

        # Render the "created by" text and blit it to the center of the screen
        created_by_text = CREDITS_FONT.render('Created by Rayyan Ahmed', True, (0, 0, 0))
        created_by_rect = created_by_text.get_rect(center=(monitor_size[0]//2, monitor_size[1]//2 - 50))
        screen.blit(created_by_text, created_by_rect)

        # Render the "thank you" text and blit it to the center of the screen
        thank_you_text = CREDITS_FONT.render('Thank you for playing!', True, (0, 0, 0))
        thank_you_rect = thank_you_text.get_rect(center=(monitor_size[0]//2, monitor_size[1]//2 + 50))
        screen.blit(thank_you_text, thank_you_rect)
        # Update the screen
        pygame.display.update()

        # Wait for a few seconds before returning to the menu
        pygame.time.wait(3000)
    if exit_button.draw(screen) == True:
        pygame.quit()
        sys.exit()
    pygame.display.update()
