from pygame.locals import *
path = "D:/Semester 2/15112/Spring semester 15112/TERM PROJ/"

def maingame(difficulty):
    import pygame, sys, csv
    from blade import SawBlade
    from game_pause_menu import pause_menu
    # Initialize Pygame
    mainClock = pygame.time.Clock()
    pygame.init()
    pygame.display.set_caption('game base')
    monitor_size = [pygame.display.Info().current_w, pygame.display.Info().current_h]
    screen = pygame.display.set_mode(monitor_size, pygame.FULLSCREEN)
    background_image = pygame.image.load(f"{path}images/rounds_bg_image.jpg")
    background_image = pygame.transform.scale(background_image, monitor_size)
    roundsMapData = []
    mapLevel = 1
    tileSize = (monitor_size[0]//29, monitor_size[1]//17)
    # FIND ROW AND COL FOR SCREEN SIZE FULL SCREEN


    # Create two saw blades with different positions and scales
    blade1 = SawBlade(f"{path}blade gif", (300, 300), (0,0))
    blade2 = SawBlade(f"{path}blade gif", (300, 300), (monitor_size[0]-300, 0))
    paused = False
    # Main game loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    # Toggle the paused variable when the Escape key is pressed
                    paused = not paused
                    if paused:
                        if pause_menu():
                            paused = False

        # If the game is resumed, clear the screen and continue with the main game loop
        if paused == False:
            screen.blit(background_image, (0, 0))
            blade1.update()
            blade1.draw(screen)
            blade2.update()
            blade2.draw(screen)
            if difficulty == "easy":
                mapLevel = 1
            if difficulty == "medium":
                mapLevel = 2
            if difficulty == "hard":
                mapLevel = 3
            # load game data from csv file based on level
            
            # ADD CHECK FOR IF LEVEL EXISTS OR NOT USING OS MODULE

            with open (f"{path}level{mapLevel}.csv", newline = "") as csvFile:
                reader = csv.reader(csvFile, delimiter = ",")
                # had to learn how to use enumerate here, as the range(len)
                # function was not a viable way to iterate through the csv file
                for x, row in enumerate (reader):
                    l = []
                    for tile in range(len(row)):
                        l.append(int(row[tile]))
                    roundsMapData.append(l)


            # create map based on the map data
                



        # Update the screen
        pygame.display.update()

        # Limit the frame rate
        mainClock.tick(60)
