import pygame

class SawBlade:
    def __init__(self, image_folder_path, scale_factor, position):
        self.scaled_frames = []
        for i in range(5):
            gif = pygame.image.load(f"{image_folder_path}/{i}.gif")
            gif = pygame.transform.scale(gif, scale_factor)
            self.scaled_frames.append(gif)
    

        # Set the initial frame and position of the saw blade
        self.frame_index = 0
        self.rect = self.scaled_frames[0].get_rect(topleft=position)


    def update(self):
        self.frame_index = (self.frame_index + 1) % len(self.scaled_frames)

    def draw(self, surface):
        surface.blit(self.scaled_frames[self.frame_index], self.rect)